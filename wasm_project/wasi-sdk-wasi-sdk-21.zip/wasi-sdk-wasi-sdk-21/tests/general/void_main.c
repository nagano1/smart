#include <stdio.h>

int main(void) {
    puts("hello from void main!");
    return 0;
}
