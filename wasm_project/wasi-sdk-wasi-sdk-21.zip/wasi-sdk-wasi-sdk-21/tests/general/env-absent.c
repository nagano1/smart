#include <stdlib.h>
#include <stdio.h>

int main(void) {
    printf("HELLO = %s\n", getenv("HELLO"));
    return 0;
}
