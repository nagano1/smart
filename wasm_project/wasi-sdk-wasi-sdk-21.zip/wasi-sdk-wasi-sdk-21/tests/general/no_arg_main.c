#include <stdio.h>

int main() {
    puts("hello from no-arg main!");
    return 0;
}
