#include <stdio.h>

int main() {
    puts("hello from C++ no-arg main!");
    return 0;
}
